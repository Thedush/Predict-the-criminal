from sklearn import svm
from sklearn import tree
import csv
import numpy as np
import pickle
rowinlist=['PERID','IFATHER','NRCH17_2','IRHHSIZ2','IIHHSIZ2','IRKI17_2','IIKI17_2','IRHH65_2','IIHH65_2','PRXRETRY','PRXYDATA','MEDICARE','CAIDCHIP',
			'CHAMPUS','PRVHLTIN','GRPHLTIN','HLTINNOS','HLCNOTYR','HLCNOTMO','HLCLAST','HLLOSRSN','HLNVCOST','HLNVOFFR','HLNVREF',
			'HLNVNEED','HLNVSOR','IRMCDCHP','IIMCDCHP','IRMEDICR','IIMEDICR','IRCHMPUS','IICHMPUS','IRPRVHLT','IIPRVHLT','IROTHHLT',
			'IIOTHHLT','HLCALLFG','HLCALL99','ANYHLTI2','IRINSUR4','IIINSUR4','OTHINS','CELLNOTCL','CELLWRKNG',
			'IRFAMSOC','IIFAMSOC','IRFAMSSI','IIFAMSSI','IRFSTAMP','IIFSTAMP','IRFAMPMT','IIFAMPMT','IRFAMSVC',
			'IIFAMSVC','IRWELMOS','IIWELMOS','IRPINC3','IRFAMIN3','IIPINC3','IIFAMIN3','GOVTPROG','POVERTY3',
			'TOOLONG','TROUBUND','PDEN10','COUTYP2','MAIIN102','AIIND102','ANALWT_C','VESTR','VEREP']
y=['Criminal']

# with open('criminal_test.csv', 'rb') as csvfile:
#      spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
#      for row in spamreader:
#      	# print row
#       #   print alist.join(row)
        
#       #   print (alist)
#         row1= next(row)
#         print row1
#         break
x=[]
y=[]
# j=0
with open('criminal_train.csv') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
    	x1=list()
    	for i in range (0,71):
         	#print(row[rowinlist[i]])
         	x1.append(row[rowinlist[i]])
        x.append(x1)
        y.append(row['Criminal'])
        # j=j+1
        # print j
        # print x
        # print y
        # if j>=2:
        # 	break
#print y
with open('xdata', 'wb') as f:
        pickle.dump(x, f)  
with open('ydata', 'wb') as f:
        pickle.dump(y, f) 

# print "Training svm training started"       	
# clf = svm.SVC(kernel='rbf',C=10000 )
# clf.fit(x, y)
# print "Training completed"
# model_save_path='trained_criminal_svm_model.clf'
# if model_save_path is not None:
#         with open(model_save_path, 'wb') as f:
#             pickle.dump(clf, f)

print "Decision tree Training started"       	
clf = tree.DecisionTreeClassifier()
clf.fit(x, y)
print "Training completed"
model_save_path='trained_criminal_tree_model.clf'
if model_save_path is not None:
        with open(model_save_path, 'wb') as f:
            pickle.dump(clf, f)
x=[]

with open('criminal_test.csv') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:

    	x1=list()
    	for i in range (0,71):
         	#print(row[rowinlist[i]])
         	x1.append(row[rowinlist[i]])
        x.append(x1)
print "pridiction start"
for j in range(0,2:
	x1=[]
	x1.append(x[j])
	pridict=clf.predict(x1)
	print x[j][0],pridict,x1
# with open('criminal_test.csv') as csvfile:
#     reader = csv.DictReader(csvfile)
#     for row in reader:
#     	x=[]
    	
#     	for i in range (0,71):
#          	#print(row[rowinlist[i]])
#          	x.append(row[rowinlist[i]])
#         pridict=clf.predict(x)
#         print predict

        
